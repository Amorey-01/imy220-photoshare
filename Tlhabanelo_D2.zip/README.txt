IMY 220 - Deliverable 2
GallerSketch - Photo Sharing Website

GitHub repository: https://github.com/Amorey-01/imy220-photoshare/tree/main

MONGODB CONNECTION STRING (Atlas)
  MONGO_URI=mongodb+srv://u25074726_db_user:oaRpD4tWIOOTNNtu@cluster0.osskukg.mongodb.net/?appName=Cluster0  DB_NAME=frame
  (Whitelist 0.0.0.0/0 in Atlas > Network Access so markers can connect.)

RUN WITH DOCKER
  1. Make sure Docker Desktop is running.
  2. From the project root:

       docker compose up --build

  4. Frontend: http://localhost:5173
     Backend:  http://localhost:5000/api

  Stop:      docker compose down
  Rebuild:   docker compose up --build --force-recreate

  Individual images (equivalent to what compose does):
       docker build -t frame-backend ./backend
       docker run -p 5000:5000 --env-file .env frame-backend
       docker build -t frame-frontend ./frontend
       docker run -p 5173:5173 -e API_TARGET=http://host.docker.internal:5000 frame-frontend

SELF-HOSTED MONGODB (instead of Atlas)
  Set MONGO_URI=mongodb://mongo:27017 in .env, then:
       docker compose --profile local up --build
  The backend seeds the database automatically on first start.

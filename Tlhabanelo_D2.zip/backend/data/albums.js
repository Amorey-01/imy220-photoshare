const { col } = require('../db');
const posts = require('./posts');

const create = async (a) => {
  const doc = { postIds: [], createdAt: new Date(), ...a };
  const r = await col('albums').insertOne(doc);
  return { ...doc, _id: r.insertedId };
};
const find = (filter = {}) => col('albums').find(filter).sort({ createdAt: -1 }).toArray();
const findById = (id) => col('albums').findOne({ _id: id });
const update = (id, fields) => col('albums').updateOne({ _id: id }, { $set: fields });
const remove = (id) => col('albums').deleteOne({ _id: id });
const addPost = (id, postId) => col('albums').updateOne({ _id: id }, { $addToSet: { postIds: postId } });
const removePost = (id, postId) => col('albums').updateOne({ _id: id }, { $pull: { postIds: postId } });
const withPosts = async (album) => ({ ...album, posts: await posts.find({ _id: { $in: album.postIds } }) });

module.exports = { create, find, findById, update, remove, addPost, removePost, withPosts };

const { col, ObjectId } = require('../db');
const users = require('./users');

const CARD = { username: 1, name: 1, profilePic: 1 };

// Replace authorId / comment userIds with small author objects for the frontend.
async function withAuthors(posts) {
  const ids = new Set();
  posts.forEach((p) => { ids.add(String(p.authorId)); (p.comments || []).forEach((c) => ids.add(String(c.userId))); });
  const found = await users.findMany([...ids].map((i) => new ObjectId(i)), CARD);
  const map = Object.fromEntries(found.map((u) => [String(u._id), u]));
  const ghost = { username: '[deleted]' };
  return posts.map((p) => ({
    ...p,
    author: map[String(p.authorId)] || ghost,
    comments: (p.comments || []).map((c) => ({ ...c, author: map[String(c.userId)] || ghost })),
  }));
}

const create = async (post) => {
  const doc = { comments: [], likes: [], createdAt: new Date(), ...post };
  const r = await col('posts').insertOne(doc);
  return { ...doc, _id: r.insertedId };
};
const find = async (filter = {}) => withAuthors(await col('posts').find(filter).sort({ createdAt: -1 }).limit(100).toArray());
const findById = async (id) => {
  const p = await col('posts').findOne({ _id: id });
  return p ? (await withAuthors([p]))[0] : null;
};
const findRaw = (id) => col('posts').findOne({ _id: id });
const update = (id, fields) => col('posts').updateOne({ _id: id }, { $set: fields });
const remove = async (id) => {
  await col('posts').deleteOne({ _id: id });
  await col('albums').updateMany({}, { $pull: { postIds: id } });
  await col('reports').deleteMany({ postId: id });
};
const addComment = (id, comment) => col('posts').updateOne({ _id: id }, { $push: { comments: comment } });
const removeComment = (id, commentId) => col('posts').updateOne({ _id: id }, { $pull: { comments: { _id: commentId } } });
const toggleLike = async (id, userId, liked) =>
  col('posts').updateOne({ _id: id }, liked ? { $pull: { likes: userId } } : { $addToSet: { likes: userId } });

module.exports = { create, find, findById, findRaw, update, remove, addComment, removeComment, toggleLike, withAuthors };

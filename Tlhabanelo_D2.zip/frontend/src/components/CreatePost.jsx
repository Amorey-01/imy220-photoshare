import { useState } from 'react';
import { api, fileToDataUrl } from '../api';

function CreatePost({ onCreated }) {
  const [image, setImage] = useState('');
  const [description, setDescription] = useState('');
  const [hashtags, setHashtags] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function pickImage(e) {
    const file = e.target.files[0];
    if (!file) return;
    try { setImage(await fileToDataUrl(file)); setError(''); } catch (err) { setError(err.message); }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!image) return setError('Choose an image first.');
    setBusy(true);
    try {
      const post = await api('/posts', { method: 'POST', body: { image, description, hashtags } });
      setImage(''); setDescription(''); setHashtags(''); setError('');
      e.target.reset();
      onCreated?.(post);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="card space-y-4">
      <h3 className="text-xl font-semibold">Create Post</h3>
      {error && <p className="error">{error}</p>}
      <div>
        <label htmlFor="postImage" className="label">Image</label>
        <input id="postImage" type="file" accept="image/*" onChange={pickImage}
          className="block w-full text-sm file:mr-3 file:rounded-full file:border-0 file:bg-sand file:px-4 file:py-2 file:text-sm file:font-semibold hover:file:bg-sandDark/60" />
        {image && <img src={image} alt="Preview" className="mt-3 max-h-56 rounded-xl" />}
      </div>
      <div>
        <label htmlFor="postDescription" className="label">Description</label>
        <textarea id="postDescription" rows={3} className="input" value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>
      <div>
        <label htmlFor="postHashtags" className="label">Hashtags</label>
        <input id="postHashtags" className="input" placeholder="#sketch #art" value={hashtags} onChange={(e) => setHashtags(e.target.value)} />
      </div>
      <button type="submit" className="btn-primary" disabled={busy}>{busy ? 'Posting…' : 'Post'}</button>
    </form>
  );
}

export default CreatePost;

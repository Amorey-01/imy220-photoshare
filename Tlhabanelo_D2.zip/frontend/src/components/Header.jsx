import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import Avatar from './Avatar';

function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const link = ({ isActive }) =>
    `rounded-full px-4 py-1.5 text-sm font-medium ${isActive ? 'bg-clay text-cream' : 'text-ink hover:bg-sand'}`;

  async function handleLogout() {
    await logout();
    navigate('/');
  }

  return (
    <header className="sticky top-0 z-20 border-b border-sandDark/70 bg-cream/90 backdrop-blur">
      <nav className="mx-auto flex max-w-5xl items-center gap-2 px-4 py-3">
        <Link to="/home" className="mr-4 font-display text-2xl font-bold text-clay">GallerSketch</Link>
        <NavLink to="/home" className={link}>Home</NavLink>
        <NavLink to={`/profile/${user._id}`} className={link}>Profile</NavLink>
        {user.isAdmin && <NavLink to="/admin" className={link}>Admin</NavLink>}
        <div className="ml-auto flex items-center gap-3">
          <Link to={`/profile/${user._id}`} className="hidden items-center gap-2 sm:flex">
            <Avatar user={user} size="sm" />
            <span className="text-sm font-medium">{user.username}</span>
          </Link>
          <button onClick={handleLogout} className="btn-ghost !px-4 !py-1.5">Log out</button>
        </div>
      </nav>
    </header>
  );
}

export default Header;
